package com.example.habittrackerwatch

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.rotary.onRotaryScrollEvent
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.wear.compose.material.*
import org.json.JSONArray
import org.json.JSONObject
import java.time.DayOfWeek
import java.time.LocalDate

private data class Homework(
    val subject: String,
    val title: String,
    val due: String,
    val done: Boolean = false
)

private val lessonTimes = listOf(
    "09:00–09:40", "09:50–10:30", "10:40–11:20",
    "11:40–12:20", "12:40–13:20", "13:30–14:10", "14:20–15:00"
)

private val timetable = mapOf(
    DayOfWeek.MONDAY to listOf("Русск.яз.", "Алгебра", "ИЗО", "Биология", "История", "Вероят/фи"),
    DayOfWeek.TUESDAY to listOf("Информ.", "Географ.", "Алгебра", "История", "Физ-ра", "Труд", "Литер/мед"),
    DayOfWeek.WEDNESDAY to listOf("Труд.", "Русск.яз.", "Алгебра", "Геометрия", "Физика", "Физ-ра", "Англ.яз."),
    DayOfWeek.THURSDAY to listOf("География.", "Русск.яз.", "Физика", "Геометрия", "Литер.", "Англ.яз.", "Рос."),
    DayOfWeek.FRIDAY to listOf("Англ.яз.", "Музыка", "Русск.яз.", "Физ-ра", "Биология", "История", "Физ-ра.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HabitTrackerWatch(this) }
    }
}

@Composable
private fun HabitTrackerWatch(context: Context) {
    val prefs = remember { context.getSharedPreferences("habit_tracker_watch", Context.MODE_PRIVATE) }
    val todayKey = LocalDate.now().toString()

    val habits = remember {
        mutableStateListOf<String>().apply {
            val raw = prefs.getString("habit_names", null)
            if (raw == null) addAll(listOf("Выпить воды", "Прочитать", "Подготовить рюкзак"))
            else runCatching {
                val array = JSONArray(raw)
                for (i in 0 until array.length()) add(array.getString(i))
            }
        }
    }
    val completed = remember {
        mutableStateMapOf<String, Boolean>().apply {
            runCatching {
                val array = JSONArray(prefs.getString("done_$todayKey", "[]"))
                for (i in 0 until array.length()) put(array.getString(i), true)
            }
        }
    }
    val homework = remember {
        mutableStateListOf<Homework>().apply {
            runCatching {
                val array = JSONArray(prefs.getString("homework", "[]"))
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)
                    add(Homework(
                        item.optString("subject", "Предмет"),
                        item.optString("title", "Задание"),
                        item.optString("due", "Без срока"),
                        item.optBoolean("done", false)
                    ))
                }
            }
        }
    }

    var page by remember { mutableStateOf("Главная") }
    var habitDraft by remember { mutableStateOf("") }
    var homeworkSubject by remember { mutableStateOf("") }
    var homeworkDraft by remember { mutableStateOf("") }
    var homeworkDue by remember { mutableStateOf("Сегодня") }

    fun saveHabits() {
        prefs.edit().putString("habit_names", JSONArray(habits).toString()).apply()
    }
    fun saveCompleted() {
        val array = JSONArray()
        completed.filterValues { it }.keys.forEach { array.put(it) }
        prefs.edit().putString("done_$todayKey", array.toString()).apply()
    }
    fun saveHomework() {
        val array = JSONArray()
        homework.forEach {
            array.put(JSONObject().put("subject", it.subject).put("title", it.title)
                .put("due", it.due).put("done", it.done))
        }
        prefs.edit().putString("homework", array.toString()).apply()
    }

    MaterialTheme {
        val scrollState = rememberScrollState()
        val rotaryFocusRequester = remember { FocusRequester() }
        LaunchedEffect(Unit) { rotaryFocusRequester.requestFocus() }
        Scaffold(
            timeText = { TimeText() },
            positionIndicator = { PositionIndicator(scrollState = scrollState) }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .focusRequester(rotaryFocusRequester)
                    .onRotaryScrollEvent {
                        scrollState.dispatchRawDelta(it.verticalScrollPixels)
                        true
                    }
                    .verticalScroll(scrollState)
                    .focusable()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("HABIT TRACKER", style = MaterialTheme.typography.caption2,
                    color = Color(0xFF80CBC4), fontWeight = FontWeight.Bold)
                Text(page, style = MaterialTheme.typography.title3,
                    textAlign = TextAlign.Center)
                Spacer(Modifier.height(5.dp))

                when (page) {
                    "Главная" -> {
                        val doneCount = habits.count { completed[it] == true }
                        Text("$doneCount / ${habits.size} привычек сегодня",
                            style = MaterialTheme.typography.body2,
                            color = MaterialTheme.colors.secondary)
                        Spacer(Modifier.height(7.dp))
                        menuChip("Привычки", "$doneCount выполнено") { page = "Привычки" }
                        menuChip("Школа", "Расписание на сегодня") { page = "Школа" }
                        menuChip("Задания", "${homework.count { !it.done }} осталось") { page = "Задания" }
                        menuChip("Статистика", "Прогресс за день") { page = "Статистика" }
                    }
                    "Привычки" -> {
                        Text("Нажми на привычку, чтобы отметить её",
                            style = MaterialTheme.typography.caption2,
                            textAlign = TextAlign.Center)
                        habits.forEach { name ->
                            Chip(
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text(name, maxLines = 2) },
                                secondaryLabel = {
                                    Text(if (completed[name] == true) "Выполнено ✓" else "Не выполнено")
                                },
                                onClick = {
                                    completed[name] = completed[name] != true
                                    saveCompleted()
                                },
                                colors = if (completed[name] == true)
                                    ChipDefaults.primaryChipColors()
                                else ChipDefaults.secondaryChipColors()
                            )
                        }
                        Spacer(Modifier.height(4.dp))
                        Text("Добавить привычку", style = MaterialTheme.typography.caption1)
                        draftField(habitDraft, "Название привычки") { habitDraft = it }
                        actionChip("Добавить") {
                            val value = habitDraft.trim()
                            if (value.isNotEmpty() && value !in habits) {
                                habits.add(value)
                                saveHabits()
                                habitDraft = ""
                            }
                        }
                        if (habits.isNotEmpty()) {
                            actionChip("Удалить последнюю") {
                                val removed = habits.removeAt(habits.lastIndex)
                                completed.remove(removed)
                                saveHabits()
                                saveCompleted()
                            }
                        }
                    }
                    "Школа" -> {
                        val today = LocalDate.now().dayOfWeek
                        Text(dayName(today), style = MaterialTheme.typography.caption1,
                            color = MaterialTheme.colors.secondary)
                        val lessons = timetable[today]
                        if (lessons == null) {
                            Text("Сегодня уроков нет", textAlign = TextAlign.Center)
                        } else {
                            lessons.forEachIndexed { index, subject ->
                                val lessonNumber = if (today == DayOfWeek.MONDAY) index + 2 else index + 1
                                val time = lessonTimes[lessonNumber - 1]
                                Chip(
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("$lessonNumber · $subject", maxLines = 2) },
                                    secondaryLabel = { Text(time) },
                                    onClick = { },
                                    colors = ChipDefaults.secondaryChipColors()
                                )
                            }
                        }
                        Text("Время уроков указано по твоему расписанию.",
                            style = MaterialTheme.typography.caption2,
                            textAlign = TextAlign.Center)
                    }
                    "Задания" -> {
                        if (homework.isEmpty()) {
                            Text("Пока нет домашних заданий", textAlign = TextAlign.Center)
                        }
                        homework.forEachIndexed { index, item ->
                            Chip(
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("${item.subject}: ${item.title}", maxLines = 2) },
                                secondaryLabel = {
                                    Text("${item.due} · ${if (item.done) "Готово ✓" else "Не готово"}")
                                },
                                onClick = {
                                    homework[index] = item.copy(done = !item.done)
                                    saveHomework()
                                },
                                colors = if (item.done) ChipDefaults.primaryChipColors()
                                    else ChipDefaults.secondaryChipColors()
                            )
                        }
                        Spacer(Modifier.height(4.dp))
                        Text("Новое задание", style = MaterialTheme.typography.caption1)
                        draftField(homeworkSubject, "Предмет") { homeworkSubject = it }
                        draftField(homeworkDraft, "Что задали?") { homeworkDraft = it }
                        draftField(homeworkDue, "Срок: Сегодня / Завтра") { homeworkDue = it }
                        actionChip("Сохранить задание") {
                            val title = homeworkDraft.trim()
                            if (title.isNotEmpty()) {
                                homework.add(Homework(
                                    homeworkSubject.trim().ifEmpty { "Школа" },
                                    title,
                                    homeworkDue.trim().ifEmpty { "Без срока" }
                                ))
                                saveHomework()
                                homeworkSubject = ""
                                homeworkDraft = ""
                                homeworkDue = "Сегодня"
                            }
                        }
                        if (homework.isNotEmpty()) {
                            actionChip("Удалить последнее") {
                                homework.removeAt(homework.lastIndex)
                                saveHomework()
                            }
                        }
                    }
                    "Статистика" -> {
                        val doneCount = habits.count { completed[it] == true }
                        Text("$doneCount / ${habits.size}",
                            style = MaterialTheme.typography.display2,
                            color = Color(0xFF80CBC4))
                        Text("привычек выполнено сегодня",
                            style = MaterialTheme.typography.caption1,
                            textAlign = TextAlign.Center)
                        Spacer(Modifier.height(8.dp))
                        Text("${homework.count { it.done }} / ${homework.size}",
                            style = MaterialTheme.typography.title2)
                        Text("домашних заданий выполнено",
                            style = MaterialTheme.typography.caption1,
                            textAlign = TextAlign.Center)
                    }
                }

                if (page != "Главная") {
                    Spacer(Modifier.height(8.dp))
                    Chip(
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("← На главную") },
                        onClick = { page = "Главная" },
                        colors = ChipDefaults.secondaryChipColors()
                    )
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun menuChip(title: String, subtitle: String, onClick: () -> Unit) {
    Chip(
        modifier = Modifier.fillMaxWidth(),
        label = { Text(title) },
        secondaryLabel = { Text(subtitle) },
        onClick = onClick,
        colors = ChipDefaults.secondaryChipColors()
    )
}

@Composable
private fun actionChip(title: String, onClick: () -> Unit) {
    Chip(
        modifier = Modifier.fillMaxWidth(),
        label = { Text(title, textAlign = TextAlign.Center) },
        onClick = onClick,
        colors = ChipDefaults.primaryChipColors()
    )
}

@Composable
private fun draftField(value: String, hint: String, onChange: (String) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)) {
        Text(hint, style = MaterialTheme.typography.caption2,
            color = MaterialTheme.colors.secondary)
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = true,
            textStyle = TextStyle(
                color = MaterialTheme.colors.onBackground,
                fontSize = 14.sp,
                textAlign = TextAlign.Center
            ),
            modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
        )
        Divider(color = MaterialTheme.colors.onSurface.copy(alpha = 0.25f))
    }
}

private fun dayName(day: DayOfWeek): String = when (day) {
    DayOfWeek.MONDAY -> "Понедельник"
    DayOfWeek.TUESDAY -> "Вторник"
    DayOfWeek.WEDNESDAY -> "Среда"
    DayOfWeek.THURSDAY -> "Четверг"
    DayOfWeek.FRIDAY -> "Пятница"
    DayOfWeek.SATURDAY -> "Суббота"
    DayOfWeek.SUNDAY -> "Воскресенье"
}
